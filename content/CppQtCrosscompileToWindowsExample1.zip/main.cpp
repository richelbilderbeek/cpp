#include <iostream>

int main()
{
  std::cout <<
    "I am developed under Unbuntu, "
    "and I will run under Windows\n";
}
