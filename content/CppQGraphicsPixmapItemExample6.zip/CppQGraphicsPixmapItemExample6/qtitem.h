#ifndef QTITEM_H
#define QTITEM_H

#include <QGraphicsPixmapItem>

///A QGraphicsPixmapItem that loads its pixmap from resources
///and is clickable
struct QtItem : public QGraphicsPixmapItem
{
  QtItem(QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  protected:
  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // QTITEM_H
