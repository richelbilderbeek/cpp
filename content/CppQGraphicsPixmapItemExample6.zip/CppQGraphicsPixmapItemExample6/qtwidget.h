#ifndef QTWIDGET_H
#define QTWIDGET_H

#include <QGraphicsView>

///Forward declaration
struct QtItem;

struct QtWidget : public QGraphicsView
{
  QtWidget();

  protected:
  void mouseMoveEvent(QMouseEvent *event);
};

#endif // QTWIDGET_H
