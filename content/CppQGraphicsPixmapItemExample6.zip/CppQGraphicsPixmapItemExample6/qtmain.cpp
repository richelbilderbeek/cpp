#include <QApplication>
#include "qtwidget.h"

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  QtWidget w;
  w.setGeometry(100,100,400,400);
  w.show();
  return a.exec();
}
