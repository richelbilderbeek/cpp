#include <iostream>
#include <gmpxx.h>

///From http://www.richelbilderbeek.nl/CppMpz_tToStr.htm
const std::string Mpz_tToStr(const mpz_t& i)
{
  static char buffer[256];
  mpz_get_str(buffer,10,i);
  return std::string(buffer);
}

int main()
{
  mpz_t i;
  mpz_init_set_str(i,"123456789012345678901234567890",10);
  //Perform i = i * i
  mpz_mul(i,i,i);

  std::cout
    << "Hello GMP,\n"
    << Mpz_tToStr(i) << " times.\n";

  mpz_clear(i);
}
