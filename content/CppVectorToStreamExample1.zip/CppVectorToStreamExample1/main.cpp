#include <iostream>
#include <iterator>
#include <cassert>
#include <algorithm>
#include <fstream>
#include <string>
#include <vector>

std::ostream& operator<<(std::ostream& os, const std::vector<std::string>& v)
{
  //Check data
  #ifndef NDEBUG
  std::for_each(v.begin(),v.end(),
    [&os](const std::string& s)
    {
      assert(s != "</>" && "Text must not be '</>'");
      assert(std::count(s.begin(),s.end(),' ') == 0 && "Text must not contain spaces");
    }
  );
  #endif
  //Write start tag
  os << "<>\n";
  //Write data
  std::for_each(v.begin(),v.end(),
    [&os](const std::string& s)
    {
      os << s << '\n';
    }
  );
  //Write end tag
  os << "</>";
  return os;
}

std::istream& operator>>(std::istream& is, std::vector<std::string>& v)
{
  //Read start tag
  {
    std::string s; is >> s; assert(s == std::string("<>"));
  }
  //Read data until end tag
  while (1)
  {
    std::string s;
    is >> s;
    if (s == std::string("</>")) return is;
    v.push_back(s);
  }
}

int main()
{
  const std::vector<std::string> v(
    {
      "aahs",
      "aals",
      "abac",
      "abas",
      "abba",
      "abbe",
      "abbs",
      "abed",
      "abet",
      "abid"
    }
  );
  const std::string filename = "tmp.txt";
  //Write to file
  {
    std::ofstream f(filename.c_str());
    f << v;
  }
  //Read from file
  {
    std::vector<std::string> w;
    std::ifstream f(filename.c_str());
    f >> w;
    if (v != w)
    {
      std::copy(w.begin(),w.end(),std::ostream_iterator<std::string>(std::cout,"\n"));
    }
    assert(v == w);
  }
}
