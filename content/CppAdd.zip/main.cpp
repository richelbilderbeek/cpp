#include <algorithm>
#include <vector>

//From http://www.richelbilderbeek.nl/CppAdd.htm
const std::vector<int> AddCpp0x(const std::vector<int>& v, const int x)
{
  std::vector<int> w(v);
  std::for_each(w.begin(),w.end(),[x](int&i) { i+=x; } );
  return w;
}

#include <algorithm>
#include <functional>
#include <numeric>
#include <vector>

//From http://www.richelbilderbeek.nl/CppAdd.htm
const std::vector<int> AddStl(const std::vector<int>& v, const int x)
{
  std::vector<int> v_new;
  std::transform(v.begin(),v.end(),std::back_inserter(v_new),
    std::bind2nd(std::plus<int>(),x));
  return v_new;
}

#include <vector>

const std::vector<int> AddFor(const std::vector<int>& v, const int x)
{
  std::vector<int> v_new(v); //Copy original vector
  const int sz = static_cast<int>(v.size());
  for (int i=0; i!=sz; ++i)
  {
    v_new[i]+=x;
  }
  return v_new;
}

#include <cassert>

int main()
{
  std::vector<int> v(4,4);
  v = AddFor(v,2);
  assert(v[1] == 6);
  v = AddStl(v,2);
  assert(v[2] == 8);
  v = AddCpp0x(v,2);
  assert(v[3] == 10);
}
