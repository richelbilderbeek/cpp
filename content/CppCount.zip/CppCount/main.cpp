#include <cassert>
#include <vector>

namespace my_old {

int Count(const std::vector<std::vector<int> >& v, const int value)
{
  int cnt = 0;
  const std::size_t maxi = v.size();
  for (std::size_t i = 0; i!=maxi; ++i)
  {
    const std::vector<int>& w = v[i];
    const std::size_t maxj = w.size();
    for (std::size_t j = 0; j!=maxj; ++j)
    {
      if (w[j] == value) ++cnt;
    }
  }
  return cnt;
}

} //~my_old


#include <algorithm>
#include <numeric>

namespace my_new {

int Count(const std::vector<std::vector<int> >& v, const int value)
{
  return std::accumulate(v.begin(),v.end(),0,
    [value](int& sum, const std::vector<int>& w)
    {
      return sum + std::count(w.begin(),w.end(),value);
    }
  );
}

} //~my_new


int main()
{
  //Creates a jagged (that is, non-square) two dimensional std:vector
  const std::vector<std::vector<int> > v = { {}, {1}, {2,2}, {3,3,3}, {4,4,4,4} };

  assert(my_old::Count(v,0) == 0);
  assert(my_old::Count(v,1) == 1);
  assert(my_old::Count(v,2) == 2);
  assert(my_old::Count(v,3) == 3);
  assert(my_old::Count(v,4) == 4);
  assert(my_old::Count(v,5) == 0);

  assert(my_new::Count(v,0) == 0);
  assert(my_new::Count(v,1) == 1);
  assert(my_new::Count(v,2) == 2);
  assert(my_new::Count(v,3) == 3);
  assert(my_new::Count(v,4) == 4);
  assert(my_new::Count(v,5) == 0);
}
