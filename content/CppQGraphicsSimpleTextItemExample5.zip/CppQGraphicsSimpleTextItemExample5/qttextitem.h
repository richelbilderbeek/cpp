#ifndef QTTEXTITEM_H
#define QTTEXTITEM_H

#include <QGraphicsSimpleTextItem>

struct QtTextItem : public QGraphicsSimpleTextItem
{
  QtTextItem(QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // QTTEXTITEM_H
