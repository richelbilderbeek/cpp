#include <iostream>

int main()
{
  static_assert(sizeof(int) == 4,
    "int has 4 bytes");
  static_assert(sizeof(long long int) == 8,
    "long long int has 8 bytes");
  long long int x = 1;
  int y = 1;
  std::cout << "#: int - long long int\n";
  for (int i = 1; i!=64; ++i)
  {
    x*=2;
    y*=2;
    std::cout << i << ": " << x << ',' << y << '\n';
  }
}
