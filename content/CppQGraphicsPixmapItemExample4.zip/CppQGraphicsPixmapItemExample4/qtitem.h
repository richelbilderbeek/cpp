#ifndef QTITEM_H
#define QTITEM_H

#include <QGraphicsPixmapItem>
#include <boost/signals2.hpp>

///A QGraphicsPixmapItem that loads its pixmap from resources
///and is clickable
struct QtItem : public QGraphicsPixmapItem
{
  QtItem(QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  ///Signal emitted when clicked
  boost::signals2::signal<void (QtItem*)> m_clicked_signal;


  protected:
  void mousePressEvent(QGraphicsSceneMouseEvent *event);

  void hoverMoveEvent(QGraphicsSceneHoverEvent *event);

  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

};

#endif // QTITEM_H
