#ifndef QTWIDGET_H
#define QTWIDGET_H

#include <QGraphicsView>

///Forward declaration
struct QtItem;

struct QtWidget : public QGraphicsView
{
  QtWidget();

  ///Respond to a click on a QtItem
  void OnItemClick(QtItem * const item);
};

#endif // QTWIDGET_H
