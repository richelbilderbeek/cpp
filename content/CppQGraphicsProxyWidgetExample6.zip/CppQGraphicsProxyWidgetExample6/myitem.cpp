#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "myitem.h"

#pragma GCC diagnostic ignored "-Weffc++"
#include <QLineEdit>
#include <QLabel>
#include <QVBoxLayout>
#pragma GCC diagnostic pop

#include "myitem.h"

MyItem::MyItem(QWidget *parent, Qt::WindowFlags f)
  : QWidget(parent,f),
    m_edit(new QLineEdit(this)),
    m_label(new QLabel(this))
{
  assert(!this->layout());
  QVBoxLayout * const layout = new QVBoxLayout(this);
  this->setLayout(layout);
  layout->addWidget(m_label);
  layout->addWidget(m_edit);
  QObject::connect(m_edit,SIGNAL(returnPressed()),this,SLOT(LoseFocus()));
}

void MyItem::LoseFocus()
{
  //Really get rid of the focus
  this->clearFocus();
  this->setEnabled(false);
  m_signal_lose_focus(this);
  //Enable the item again
  this->setEnabled(true);
}

void MyItem::mousePressEvent(QMouseEvent * event)
{
  m_signal_mouse_press(this);
  QWidget::mousePressEvent(event);
}


void MyItem::mouseDoubleClickEvent(QMouseEvent *)
{
  LoseFocus();
}
