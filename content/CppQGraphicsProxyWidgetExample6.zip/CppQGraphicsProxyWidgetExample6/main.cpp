#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

#pragma GCC diagnostic ignored "-Weffc++"
#include <QApplication>
#include <QDesktopWidget>
#pragma GCC diagnostic pop

#include "myview.h"

int main(int argc, char **argv)
{
  //Create the application
  QApplication app(argc, argv);
  MyView view;
  view.setGeometry(0,0,800,600);
  {
    //Put the dialog in the screen center
    const QRect screen = QApplication::desktop()->screenGeometry();
    view.move( screen.center() - view.rect().center() );
  }
  view.show();
  return app.exec();
}
