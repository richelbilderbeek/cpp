#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "myview.h"


#include <cassert>
#include <cmath>

#pragma GCC diagnostic ignored "-Weffc++"
#include <QGraphicsProxyWidget>
#include <QGraphicsScene>
#include <QLabel>
#include <QLineEdit>
#include <QDialog>
#include <QGraphicsSceneMouseEvent>
#pragma GCC diagnostic pop


MyView::MyView(QWidget *parent)
  : QGraphicsView(parent),
    m_scene(new QGraphicsScene(this)),
    m_drag_item(nullptr)
{
  this->setScene(m_scene);
  //Create the QLineEdit instances
  const int sz = 10;
  std::vector<QGraphicsProxyWidget *> proxies;
  for (int i=0; i!=sz; ++i)
  {
    MyItem * const item = new MyItem;
    item->setGeometry(0,0,100,22);
    item->m_label->setText(QString("#") + QString::number(i));
    item->m_edit->setText(QString("Text ") + QString::number(i));
    item->m_signal_mouse_press.connect(
      boost::bind(
        &MyView::OnMousePress,
        this,_1)); //_1 because the signal contains an argument
    item->m_signal_lose_focus.connect(
      boost::bind(
        &MyView::OnItemNoFocus,
        this,_1)); //_1 because the signal contains an argument
    //Add the QWidget and obtain its proxy
    QGraphicsProxyWidget * const proxy = m_scene->addWidget(item);
    proxies.push_back(proxy);
    m_m[item] = proxy;
  }

  const double ray = 200.0; //pixels
  for (int i=0; i!=sz; ++i)
  {
    const double angle = 2.0 * M_PI * static_cast<double>(i) / static_cast<double>(sz);
    const int x = static_cast<int>(0.0 + (std::sin(angle) * ray));
    const int y = static_cast<int>(0.0 - (std::cos(angle) * ray));
    QGraphicsProxyWidget * const proxy = proxies[i];
    proxy->setRotation(angle * 360.0 / (2.0 * M_PI));
    proxy->setPos(x,y);
    proxy->setFlag(QGraphicsItem::ItemIsMovable,true); //No need to set this flag
  }
}

void MyView::OnMousePress(MyItem * item)
{
  assert(item);
  m_drag_item = item;
  //item->m_edit->setText("Gotcha!");
}

void MyView::OnItemNoFocus(MyItem * item)
{
  assert(item);
  //item->m_edit->setText("Lost focus");
  this->setFocus();
  m_drag_item = nullptr;
  assert(!m_drag_item);
}

void MyView::mouseMoveEvent(QMouseEvent *event)
{
  if (m_drag_item)
  {
    //Convert the position clicked to the QGraphicsView coordinat
    const QPointF p = this->mapToScene(event->pos());
    //Let the item follow the mouse cursor
    m_m[m_drag_item]->setPos(p);
  }
}

void MyView::mouseReleaseEvent(QMouseEvent *)
{
  m_drag_item = nullptr;
}
