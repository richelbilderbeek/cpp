#ifndef MYITEM_H
#define MYITEM_H

#include <QWidget>
#include <boost/signals2.hpp>

struct QLabel;
struct QLineEdit;

class MyItem : public QWidget
{
  Q_OBJECT

  public:
  explicit MyItem(QWidget *parent = 0, Qt::WindowFlags f = 0);
  boost::signals2::signal<void (MyItem*)> m_signal_mouse_press;
  boost::signals2::signal<void (MyItem*)> m_signal_lose_focus;
  protected:
  void mousePressEvent(QMouseEvent * event);
  void mouseDoubleClickEvent(QMouseEvent * event);
  public slots:
  void LoseFocus();

  public:
  QLineEdit * const m_edit;
  QLabel * const m_label;
};

#endif // MYITEM_H
