#ifndef MYVIEW_H
#define MYVIEW_H

#include <QGraphicsView>


#include "myitem.h"

struct MyItem;
struct QGraphicsScene;

class MyView : public QGraphicsView
{
  Q_OBJECT

  public:
  explicit MyView(QWidget *parent = 0);

  protected:
  void mouseMoveEvent(QMouseEvent *event);
  void mouseReleaseEvent(QMouseEvent *);

  private:
  QGraphicsScene * const m_scene;
  MyItem * m_drag_item;
  std::map<MyItem *,QGraphicsProxyWidget *> m_m;

  //My own added method
  void OnMousePress(MyItem * item);
  //An item wants to get rid of its focus
  void OnItemNoFocus(MyItem * item);
};

#endif // MYVIEW_H
