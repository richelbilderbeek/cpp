#include <cln/cln.h>
#include <iostream>

int main()
{
  cln::cl_I i = "123456789012345678901234567890";
  const cln::cl_I j = i * i;
  std::cout << "Hello CLN,\n" << j << " times\n";
}
