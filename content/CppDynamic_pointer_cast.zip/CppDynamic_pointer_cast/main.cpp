#include <cassert>
#include <iostream>
#include <boost/shared_ptr.hpp>


struct Base
{
  virtual ~Base() {}
  void BaseSayHi() const { std::cout << "Base says hi\n"; }
};

struct Derived : public Base
{
  void DerivedSayHi() const { std::cout << "Derived says hi\n"; }

};

int main()
{
  //Base initialized with derived, can be downcasted to derived
  {
    const boost::shared_ptr<Base> p1(new Derived);
    const boost::shared_ptr<Derived> p2(boost::dynamic_pointer_cast<Derived>(p1));
    assert(p1);
    assert(p2);
    assert(p1 == p2);
    assert(p1.use_count() == 2);
    assert(p2.use_count() == 2);
  }
  //Base initialized with base, cannot be downcasted to derived
  {
    const boost::shared_ptr<Base> p1(new Base);
    const boost::shared_ptr<Derived> p2(boost::dynamic_pointer_cast<Derived>(p1));
    assert( p1);
    assert(!p2);
    assert(p1 != p2);
    assert(p1.use_count() == 1);
  }
  //Const base initialized with derived, can be downcasted to const derived
  {
    const boost::shared_ptr<const Base> p1(new Derived);
    const boost::shared_ptr<const Derived> p2(boost::dynamic_pointer_cast<const Derived>(p1));
    assert(p1);
    assert(p2);
    assert(p1 == p2);
    assert(p1.use_count() == 2);
    assert(p2.use_count() == 2);
  }
  //Const base initialized with base, cannot be downcasted to const derived
  {
    const boost::shared_ptr<const Base> p1(new Base);
    const boost::shared_ptr<const Derived> p2(boost::dynamic_pointer_cast<const Derived>(p1));
    assert( p1);
    assert(!p2);
    assert(p1 != p2);
    assert(p1.use_count() == 1);
  }
  //Const base initialized with derived, cannot be down- and const-casted to non-const derived
  {
    const boost::shared_ptr<const Base> p1(new Derived);
    //Removing const: will and should not compile
    //const boost::shared_ptr<Derived> p2(boost::dynamic_pointer_cast<Derived>(p1));
    assert(p1);
  }
  //Base initialized with derived, can be downcasted to const derived with adding constness
  {
    const boost::shared_ptr<Base> p1(new Derived);
    //Adding const: will and should compile
    const boost::shared_ptr<const Derived> p2(boost::dynamic_pointer_cast<const Derived>(p1));
    assert(p1);
    assert(p2);
    assert(p1 == p2);
    assert(p1.use_count() == 2);
    assert(p2.use_count() == 2);
  }
  //Delete one of the two instances
  for (int i=0; i!=2; ++i)
  {
    boost::shared_ptr<Base> p1(new Derived);
    boost::shared_ptr<Derived> p2(boost::dynamic_pointer_cast<Derived>(p1));
    assert(p1);
    assert(p2);
    assert(p1 == p2);
    assert(p1.use_count() == 2);
    assert(p2.use_count() == 2);

    if (i % 2)
    {
      p1.reset(new Base);
    }
    else
    {
      p2.reset(new Derived);
    }
    assert(p1 != p2);
    assert(p1.use_count() == 1);
    assert(p2.use_count() == 1);
  }
}
