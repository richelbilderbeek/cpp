/*
 * Copyright (C) 2008 Emweb bvba, Heverlee, Belgium.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include <iostream>
#include <vector>

#include <boost/program_options.hpp>

#include <Wt/WBreak>
#include <Wt/WContainerWidget>
#include <Wt/WLineEdit>
#include <Wt/WPushButton>
#include <Wt/WText>

#include "HelloApplication.h"
#include "QtObject.h"

using namespace Wt;

HelloApplication::HelloApplication(const WEnvironment& env)
  : WQApplication(env)
{
  /*
   * Note: do not create any Qt objects from here. Initialize your
   * application from within the virtual create() method.
   */
}

void HelloApplication::create()
{
  setTitle("CppWtWithQt");

  root()->addWidget(new WText("Your name, please ? "));
  nameEdit_ = new WLineEdit(root());
  nameEdit_->setFocus();

  WPushButton *b = new WPushButton("Greet me.", root());
  b->setMargin(5, Left);

  root()->addWidget(new WBreak());

  greeting_ = new WText(root());

  b->clicked().connect(this, &HelloApplication::propagateGreet);
  nameEdit_->enterPressed().connect(this, &HelloApplication::propagateGreet);

  qtSender_ = new QtObject(this);
  qtReceiver_ = new QtObject(this);

  QObject::connect(qtSender_, SIGNAL(greet(const QString&)),
		   qtReceiver_, SLOT(doGreet(const QString&)));
}

void HelloApplication::destroy()
{
  /*
   * Note: Delete any Qt object from here.
   */
  delete qtSender_;
  delete qtReceiver_;
}

void HelloApplication::propagateGreet()
{
  qtSender_->passGreet(toQString(nameEdit_->text()));
}

void HelloApplication::doGreet(const QString& qname)
{
  greeting_->setText("Hello there, " + toWString(qname));
}

WApplication *createApplication(const WEnvironment& env)
{
  return new HelloApplication(env);
}

int main(int argc, char **argv)
{
 // Declare the supported options.
  boost::program_options::options_description d(
    "Allowed options for TestLed");
  std::string docroot;
  std::string http_address;
  std::string http_port;
  d.add_options()
      ("help",
        "produce this help message")
      ("docroot",
         boost::program_options::value<std::string>(&docroot)->default_value("."),
         "the docroot")
      ("http-address",
         boost::program_options::value<std::string>(&http_address)->default_value("0.0.0.0"),
         "the server's http address")
      ("http-port",
         boost::program_options::value<std::string>(&http_port)->default_value("8080"),
         "the server's http port")
      ;

  boost::program_options::variables_map m;
  boost::program_options::store(
    boost::program_options::parse_command_line(
      argc, argv, d), m);
  boost::program_options::notify(m);

  if (m.count("help"))
  {
    //Display the options_description
    std::cout << d << "\n";
    return 0;
  }

  //Create the arguments in std::string format
  std::vector<std::string> v(7);
  v[0] = argv[0];
  v[1] = "--docroot";
  v[2] = docroot;
  v[3] = "--http-address";
  v[4] = http_address;
  v[5] = "--http-port";
  v[6] = http_port;

  //Convert the arguments to char* format
  std::vector<char*> w(7);
  for (int i=0; i!=7; ++i) w[i] = &v[i][0];

  //Give Wt the modified parameters
  return WRun(w.size(), &w[0], &createApplication);

  //OLD:
  //return WRun(argc, argv, &createApplication);
}

