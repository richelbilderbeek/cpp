#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "qtroundedrectitem.h"

#include <cassert>
#include <sstream>
#include <QGraphicsScene>
#include <QPainter>

QtRoundedRectItem::QtRoundedRectItem(QGraphicsItem *parent, QGraphicsScene *scene)
 : QGraphicsRectItem(parent,scene)
{
  this->setFlags(
      QGraphicsItem::ItemIsFocusable
    | QGraphicsItem::ItemIsMovable
    | QGraphicsItem::ItemIsSelectable);

}

void QtRoundedRectItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
  if (this->isSelected())
  {
    QPen pen;
    pen.setStyle(Qt::DashLine);
    painter->setPen(pen);
  }
  painter->drawRoundedRect(this->rect(),m_radius_x,m_radius_y);
}

void QtRoundedRectItem::setRoundedRect(const QRectF rect, const double radius_x, const double radius_y)
{
  this->setRect(rect);
  this->setRadiusX(radius_x);
  this->setRadiusY(radius_y);
}
