#include <algorithm>
#include <string>
#include <vector>

int GetLongestStringLengthCpp11(const std::vector<std::string>& v)
{
  const std::vector<std::string>::const_iterator i
    = std::max_element(
      v.begin(),
      v.end(),
      [](const std::string& lhs, const std::string& rhs)
      {
        return lhs.size() < rhs.size();
      }
    );
  if (i!=v.end()) return static_cast<int>(i->size());
  return 0;
}

int GetLongestStringLengthCpp98ForLoop(const std::vector<std::string>& v)
{
  int longest = 0;
  const int sz = v.size();
  for (int i=0; i!=sz; ++i)
  {
    longest = std::max(static_cast<int>(v[i].size()),longest);
  }
  return longest;
}


#ifdef IF_I_ONLY_KNEW_HOW_TO_GET_THIS_WORKING_7737346578649782927896
#include <functional>

int GetLongestStringLengthCpp98Functor(const std::vector<std::string>& v)
{
  const std::vector<std::string>::const_iterator i
    = std::max_element(
      v.begin(),
      v.end(),
      std::mem_fun_ref(&std::string::size)
    );
  if (i!=v.end()) return static_cast<int>(i->size());
  return 0;
}
#endif

bool StringLengthCompare(const std::string& lhs, const std::string& rhs)
{
  return lhs.size() < rhs.size();
}

int GetLongestStringLengthCpp98CustomFunctor(const std::vector<std::string>& v)
{
  const std::vector<std::string>::const_iterator i
    = std::max_element(
      v.begin(),
      v.end(),
      StringLengthCompare
    );
  if (i!=v.end()) return static_cast<int>(i->size());
  return 0;
}

#include <boost/foreach.hpp>
int GetLongestStringLengthBoostForeach(const std::vector<std::string>& v)
{
  int longest = 0;
  BOOST_FOREACH(const std::string& s,v)
  {
    longest = std::max(static_cast<int>(s.size()),longest);
  }
  return longest;

}

#include <boost/bind.hpp>
#include <boost/lambda/lambda.hpp>

int GetLongestStringLengthBoostBind(const std::vector<std::string>& v)
{
  const std::vector<std::string>::const_iterator i
    = std::max_element(
      v.begin(),
      v.end(),
      boost::bind(&std::string::size,boost::lambda::_1) < boost::bind(&std::string::size,boost::lambda::_2)
    );
  if (i!=v.end()) return static_cast<int>(i->size());
  return 0;
}


#include <cassert>

int main()
{
  {
    const std::vector<std::string> v = { "1","123","123456","12345678","123456789" };
    const int expected = 9;
    assert(GetLongestStringLengthCpp11(v) == expected);
    assert(GetLongestStringLengthBoostBind(v) == expected);
    assert(GetLongestStringLengthBoostForeach(v) == expected);
    assert(GetLongestStringLengthCpp98CustomFunctor(v) == expected);
    assert(GetLongestStringLengthCpp98ForLoop(v) == expected);
  }
  {
    const std::vector<std::string> v = { "1","23","456","78","123456789","01","23","456","78","9" };
    const int expected = 9;
    assert(GetLongestStringLengthCpp11(v) == expected);
    assert(GetLongestStringLengthBoostBind(v) == expected);
    assert(GetLongestStringLengthBoostForeach(v) == expected);
    assert(GetLongestStringLengthCpp98CustomFunctor(v) == expected);
    assert(GetLongestStringLengthCpp98ForLoop(v) == expected);
  }
  {
    const std::vector<std::string> v = { "x" };
    const int expected = 1;
    assert(GetLongestStringLengthCpp11(v) == expected);
    assert(GetLongestStringLengthBoostBind(v) == expected);
    assert(GetLongestStringLengthBoostForeach(v) == expected);
    assert(GetLongestStringLengthCpp98CustomFunctor(v) == expected);
    assert(GetLongestStringLengthCpp98ForLoop(v) == expected);
  }
  {
    const std::vector<std::string> v = { };
    const int expected = 0;
    assert(GetLongestStringLengthCpp11(v) == expected);
    assert(GetLongestStringLengthBoostBind(v) == expected);
    assert(GetLongestStringLengthBoostForeach(v) == expected);
    assert(GetLongestStringLengthCpp98CustomFunctor(v) == expected);
    assert(GetLongestStringLengthCpp98ForLoop(v) == expected);
  }
}
