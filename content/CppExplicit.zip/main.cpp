struct Test
{
  explicit Test(const int x) {}
};

int main()
{
  Test t_i = 0;
}
