#include <boost/lexical_cast.hpp>
#include <boost/shared_ptr.hpp>
#include <string>

///A Strategy Design Pattern
struct StrToDoubleStrategy
{
  virtual double StrToDouble(const std::string& s) const = 0;
  virtual ~StrToDoubleStrategy() {}
};

struct StrToDoubleStrategyStl : public StrToDoubleStrategy
{
  double StrToDouble(const std::string& s) const
  {
    return std::atof(s.c_str());
  }
};

struct StrToDoubleStrategyBoost : public StrToDoubleStrategy
{
  double StrToDouble(const std::string& s) const
  {
    return boost::lexical_cast<double>(s);
  }
};

struct StrToDoubleStrategyCpp11 : public StrToDoubleStrategy
{
  double StrToDouble(const std::string& s) const
  {
    return std::stof(s);
  }
};

struct Converter
{
  Converter(const StrToDoubleStrategy * strategy)
    : m_strategy(strategy)
  {
    assert(m_strategy);
  }
  double StrToDouble(const std::string& s) const
  {
    return m_strategy->StrToDouble(s);
  }
  private:
  boost::shared_ptr<const StrToDoubleStrategy> m_strategy;
};

#include <cassert>

int main()
{

  const Converter a(new StrToDoubleStrategyStl);
  const Converter b(new StrToDoubleStrategyBoost);
  const Converter c(new StrToDoubleStrategyCpp11);
  assert( std::abs(12.34 - a.StrToDouble("12.34")) < 0.000001);
  assert( std::abs(12.34 - b.StrToDouble("12.34")) < 0.000001);
  assert( std::abs(12.34 - c.StrToDouble("12.34")) < 0.000001);
}
