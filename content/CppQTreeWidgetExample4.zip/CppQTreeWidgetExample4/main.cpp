#include <cassert>
#include <QApplication>
#include <QDebug>
#include <QDropEvent>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QDesktopWidget>

struct TwoLevelsDeepTree : public QTreeWidget
{
  protected:
  void dropEvent(QDropEvent *event)
  {
    QTreeWidget::dropEvent(event);
    //Process all items
    const int n_top = this->topLevelItemCount();
    for (int i=0; i!=n_top; ++i)
    {
      QTreeWidgetItem * const top = this->topLevelItem(i);
      //Allow dropping on top-level items
      top->setFlags(
          Qt::ItemIsSelectable
        | Qt::ItemIsEnabled
        | Qt::ItemIsEditable
        | Qt::ItemIsDragEnabled
        | Qt::ItemIsDropEnabled);
      assert(GetDepth(top)==0);
      const int n_child = top->childCount();
      for (int j=0; j!=n_child; ++j)
      {
        assert(GetDepth(top->child(j))==1);
        //Disallow dropping on non-top-level items
        top->child(j)->setFlags(
            Qt::ItemIsSelectable
          | Qt::ItemIsEnabled
          | Qt::ItemIsEditable
          | Qt::ItemIsDragEnabled);
      }
    }
  }
  private:
  ///Find out the depth of an item
  int GetDepth(const QTreeWidgetItem * const item)
  {
    assert(item);
    int depth = 0;
    const QTreeWidgetItem * copy = item->parent();
    while(copy)
    {
      ++depth;
      copy = copy->parent();
    }
    return depth;
  }
};

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  TwoLevelsDeepTree w;

  //Hide the header
  w.setHeaderHidden(true);

  //Add ten regular items
  for (int i=0; i!=10; ++i)
  {
    QTreeWidgetItem * const item = new QTreeWidgetItem;
    item->setText(0,"Item #" + QString::number(i+1));
    //Allow the item to be edited
    item->setFlags( item->flags() | Qt::ItemIsEditable);
    w.addTopLevelItem(item);
  }

  //Let the row colors alternate
  w.setAlternatingRowColors(true);

  //Allow items to be drag and dropped inside of the widget
  w.setDragDropMode(QAbstractItemView::InternalMove);

  //Let the drag and drop be animated
  w.setAnimated(true);

  w.show();

  //Put the QTreeWidget in the center of the screen at 25% of the screen its size
  {
    const QRect screen = QApplication::desktop()->screenGeometry();
    w.setGeometry(0,0,screen.width() * 1 / 4 ,screen.height() * 1 / 2);
    w.move( screen.center() - w.rect().center() );
  }
  return a.exec();
}
