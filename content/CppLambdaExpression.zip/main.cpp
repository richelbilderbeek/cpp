#include <algorithm>
#include <cassert>
#include <vector>

//C++0x lambda expression
void AbsSort(std::vector<int>& v)
{
  std::sort(
    v.begin(),
    v.end(),
    [](const int a, const int b) { return std::abs(a) < std::abs(b); } );
}

//C++0x lambda expression
//From http://www.richelbilderbeek.nl/CppAdd.htm
void Add(std::vector<int>& v, const int x)
{
  //Note the x in the capture list
  std::for_each(v.begin(),v.end(),[x](int&i) { i+=x; } );
}

#include <boost/lambda/lambda.hpp>
#include <boost/bind.hpp>

void AbsSortBoost(std::vector<int>& v)
{
  std::sort(
    v.begin(),
    v.end(),
      boost::bind(&std::labs,boost::lambda::_1)
    < boost::bind(&std::labs,boost::lambda::_2) );
}

//From http://www.richelbilderbeek.nl/CppAdd.htm
void AddBoost(std::vector<int>& v, const int x)
{
  std::transform(v.begin(),v.end(),v.begin(),std::bind2nd(std::plus<int>(),x));
}


#include <algorithm>
#include <cassert>
#include <iostream>
#include <vector>

void TestProgramFlow()
{
  //2-D std::vector, note 42 in the middle, from an initializer list
  const std::vector<std::vector<int> > v
    =
    {
      {  0, 1, 2, 3, 4 },
      { 10,11,12,13,14 },
      { 40,41,42,43,44 },
      { 50,51,52,53,54 },
      { 60,61,62,63,64 }
    };
  //First lambda expression
  std::for_each(v.begin(),v.end(),
    [](const std::vector<int>& w)
    {
      //Nested second lambda expression
      std::for_each(w.begin(),w.end(),
        [](const int i)
        {
          if (i == 42)
          {
            std::cout << "FOUND!\n";
            return; //Terminates the second lambda expression,
                    //Does not return from Test function
          }
        }
      );
    }
  );
  //Will get here, as the return statement only terminates
  //the second lambda expression, instead of the Test function
  assert(!"Should not get here");
}



int main()
{
  //TestProgramFlow();
  {
    std::vector<int> v = { 4,-3,2,-1 };
    AbsSort(v);
    assert(v[0] == -1);
    assert(v[1] ==  2);
    assert(v[2] == -3);
    assert(v[3] ==  4);
  }
  {
    std::vector<int> v = { 4,-3,2,-1 };
    AbsSortBoost(v);
    assert(v[0] == -1);
    assert(v[1] ==  2);
    assert(v[2] == -3);
    assert(v[3] ==  4);
  }
  std::vector<int> v = { 0,1,2,3 };
  Add(v,2);
  assert(v[0] == 2);
  assert(v[1] == 3);
  assert(v[2] == 4);
  assert(v[3] == 5);
  AddBoost(v,2);
  assert(v[0] == 4);
  assert(v[1] == 5);
  assert(v[2] == 6);
  assert(v[3] == 7);
}
