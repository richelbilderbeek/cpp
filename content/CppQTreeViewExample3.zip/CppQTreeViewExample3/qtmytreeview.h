#ifndef QTMYTREEVIEW_H
#define QTMYTREEVIEW_H

#include <QTreeView>

struct QtMyTreeView : public QTreeView
{
  QtMyTreeView(QWidget * const parent = 0);
};

#endif // QTMYTREEVIEW_H
