#include <iostream>
#include <thread>

void f() { std::cout << "Hello world\n"; }

int main()
{
  std::once_flag flag;
  std::call_once(flag,&f);
  std::call_once(flag,&f);
  std::call_once(flag,&f);
}

/* Screen output:

Hello world

*/
