#include "dialog.h"

#include <cassert>
#include <QDebug>
#include <QLabel>
#include <QShowEvent>
#include <QVBoxLayout>

#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::Dialog),
  m_label(new QLabel("My label"))

{
  ui->setupUi(this);

  assert(!this->layout() && "No layout is present yet");
  this->setLayout(new QVBoxLayout);
  assert(this->layout() && "Vertical layout is present");

  this->layout()->addWidget(m_label);
  assert(!m_label->isVisible() && "Label is not visible yet");
  qDebug() << "End of constructor";
}

Dialog::~Dialog()
{
  delete ui;
}

void Dialog::showEvent(QShowEvent *)
{
  assert(m_label->isVisible() && "Label has been made visible now");
  qDebug() << "End of showEvent";
}
