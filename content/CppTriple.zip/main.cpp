
#include <boost/foreach.hpp>

//From http://www.richelbilderbeek.nl/CppTriple.htm
template <class Container>
void TripleForeach(Container& c)
{
  BOOST_FOREACH(typename Container::value_type& i, c)
  {
    i*=3;
  }
}

#include <algorithm>
#include <vector>

//From http://www.richelbilderbeek.nl/CppTriple.htm
void TripleCpp0x(std::vector<int>& v)
{
  std::for_each(v.begin(),v.end(),
    [](int& i) { i*=3; } );
}

#include <algorithm>
#include <boost/lambda/lambda.hpp>

template <class Container>
void TripleLambda(Container& c)
{
  std::for_each(c.begin(),c.end(), boost::lambda::_1 *=3);
}

#include <algorithm>
#include <numeric>
#include <functional>

//From http://www.richelbilderbeek.nl/CppTriple.htm
template <class Container>
void TripleGeneral(Container& c)
{
  std::transform(c.begin(),c.end(),c.begin(),
    std::bind2nd(std::multiplies<typename Container::value_type>(),3));
}

#include <vector>
#include <algorithm>
#include <numeric>

//From http://www.richelbilderbeek.nl/CppTriple.htm
void TripleAlgorithm(std::vector<int>& v)
{
  std::transform(v.begin(),v.end(),v.begin(),
    std::bind2nd(std::multiplies<int>(),3));
}

#include <vector>

//From http://www.richelbilderbeek.nl/CppTriple.htm
void TripleFor(std::vector<int>& v)
{
  const int sz = v.size();
  for (int i=0; i!=sz; ++i)
  {
    v[i]*=3;
  }
}


#include <cassert>

int main()
{
  std::vector<int> v;
  v.push_back(1);
  TripleGeneral(v);
  assert(v[0]==3);
  TripleAlgorithm(v);
  assert(v[0]==9);
  TripleFor(v);
  assert(v[0]==27);
  TripleForeach(v);
  assert(v[0]==81);
  TripleLambda(v);
  assert(v[0]==243);
  TripleCpp0x(v);
  assert(v[0]==3*243);
}
