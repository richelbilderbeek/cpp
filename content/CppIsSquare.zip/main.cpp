#include <cassert>
#include <iterator>
#include <vector>
#include <boost/foreach.hpp>

//From http://www.richelbilderbeek.nl/CppIsSquare.htm
template <typename T>
    bool IsSquare(const std::vector<std::vector<T> >& v)
{
  assert(!v.empty());
  BOOST_FOREACH(std::vector<T> row, v)
  {
    if (row.size()!=v.size()) return false;
  }
  return true;
}

int main()
{
  std::vector<std::vector<int> > v;
  v.resize(4);
  BOOST_FOREACH(std::vector<int>& row, v)
  {
    row.resize(4);
  }
  assert(IsSquare(v)==true);
  v[3].resize(5);
  assert(IsSquare(v)==false);
}

/*
//Works under C++ Builder

//From http://www.richelbilderbeek.nl/CppIsSquare.htm
template <class T>
bool IsSquare(const std::vector<std::vector<T> >& v)
{
  if (v.empty()) return false;
  const int sz = static_cast<int>(v.size());
  const std::vector<std::vector<T> >::const_iterator j = v.end();
  std::vector<std::vector<T> >::const_iterator i = v.begin();
  for ( ; i!=j; ++i)
  {
    if (sz != static_cast<int>(i->size())) return false;
  }
  return true;
}

*/
