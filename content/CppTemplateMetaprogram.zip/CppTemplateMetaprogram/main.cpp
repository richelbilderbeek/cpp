template <bool>
struct CtAssert;

template <>
struct CtAssert<true> {};

//The template metaprogram for factorial
template <unsigned int N>
struct factorial
{
  static unsigned const value = N * factorial<N-1>::value;
};

template <>
struct factorial<0>
{
  static unsigned const value = 1;
};

int main()
{
  CtAssert<(factorial<0>::value==1)>();
  CtAssert<(factorial<1>::value==1)>();
  CtAssert<(factorial<2>::value==2)>();
  CtAssert<(factorial<3>::value==6)>();
  CtAssert<(factorial<4>::value==24)>();
  CtAssert<(factorial<5>::value==120)>();
}
