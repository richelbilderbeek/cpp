#ifndef DIALOG_H
#define DIALOG_H

#include <boost/shared_ptr.hpp>
#include <QDialog>

namespace Ui {
  class Dialog;
}

class Dialog : public QDialog
{
  Q_OBJECT

public:
  explicit Dialog(QWidget *parent = 0);
  ~Dialog();

protected:
  void changeEvent(QEvent *e);

private:
  Ui::Dialog *ui;
  void resizeEvent(QResizeEvent*);

private slots:
  void onAnyChange();
};

#endif // DIALOG_H

//From http://www.richelbilderbeek.nl/CppDrawGlobe.htm
QPixmap DrawGlobe(
  const int width,
  const int height,
  const unsigned char r,
  const unsigned char g,
  const unsigned char b);
