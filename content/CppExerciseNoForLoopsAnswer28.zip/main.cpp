#include <cassert>
#include <vector>

struct Person
{
  Person(const int id) : m_id(id) {}
  int GetId() const { return m_id; }
  const int m_id;
};

#include <boost/numeric/conversion/cast.hpp>

const Person * GetMaxIdStl(const std::vector<const Person *>& v)
{
  assert(!v.empty());
  const int size = boost::numeric_cast<int>(v.size());
  int max_id = v[0]->GetId();
  int index_max_id = 0;
  for (int i=1; i!=size; ++i)
  {
    const int id = v[i]->GetId();
    if (id > max_id)
    {
      max_id = id;
      index_max_id = i;
    }
  }
  return v[index_max_id];
}

#include <algorithm>

const Person * GetMaxIdCpp0x(const std::vector<const Person *>& v)
{
  return *(std::max_element(
    v.begin(),v.end(),
    [](const Person* const lhs,const Person* const rhs)
      { return rhs->GetId() > lhs->GetId(); }
    ));
}

#include <algorithm>
#include <boost/bind.hpp>
#include <boost/lambda/lambda.hpp>

const Person * GetMaxIdBoost(const std::vector<const Person *>& v)
{
  return *(std::max_element(
    v.begin(),v.end(),
    boost::bind(&Person::GetId,_2) > boost::bind(&Person::GetId,_1)));
}

#include <cassert>

int main()
{
  const std::vector<const Person *> v
    =
    {
      new Person(1),
      new Person(2),
      new Person(4),
      new Person(8),
      new Person(7),
      new Person(6),
      new Person(5),
      new Person(3),
    };
  assert(GetMaxIdStl(v)->GetId() == 8);
  assert(GetMaxIdCpp0x(v)->GetId() == 8);
  assert(GetMaxIdBoost(v)->GetId() == 8);
}
