#ifndef QTGROUPITEM_H
#define QTGROUPITEM_H

#include <QGraphicsItemGroup>

struct QtRectItem;
struct QtPathItem;

struct QtGroupItem : public QGraphicsItemGroup
{
  QtGroupItem(
    const QPointF& from,
    const QPointF& mid,
    const QPointF& to,
    QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  private:
  ///The curve
  const QtPathItem * m_path;

  ///The rectangle at the curve its starting position
  QtRectItem * const m_from;

  ///The rectangle at the curve its middle position
  QtRectItem * const m_mid;

  ///The rectangle at the curve its end position
  QtRectItem * const m_to;
};

#endif // QTGROUPITEM_H
