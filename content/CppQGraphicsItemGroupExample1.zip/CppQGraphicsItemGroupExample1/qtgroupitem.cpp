#include <cassert>
#include <QPainter>
#include "qtgroupitem.h"
#include "qtpathitem.h"
#include "qtrectitem.h"

QtGroupItem::QtGroupItem(
    const QPointF& from,
    const QPointF& mid,
    const QPointF& to,
  QGraphicsItem *parent, QGraphicsScene *scene)
  : QGraphicsItemGroup(parent,scene),
    m_from(new QtRectItem(this)),
    m_mid(new QtRectItem(this)),
    m_to(new QtRectItem(this))
{
  m_path = new QtPathItem(m_from,m_mid,m_to,this);
  m_from->setPos(from);
  m_mid->setPos(mid);
  m_to->setPos(to);

  this->setFlags(
      QGraphicsItem::ItemIsSelectable
    | QGraphicsItem::ItemIsMovable);
  //this->setFiltersChildEvents(false);
}
