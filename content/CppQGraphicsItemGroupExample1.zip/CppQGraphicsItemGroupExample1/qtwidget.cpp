#include <cassert>
#include <QGraphicsScene>
#include "qtrectitem.h"
#include "qtgroupitem.h"
#include "qtpathitem.h"
#include "qtwidget.h"

QtWidget::QtWidget(QWidget *parent)
  : QGraphicsView(new QGraphicsScene,parent)
{
  const int n_items = 16;
  std::vector<QtRectItem *> rects;

  for (int i=0; i!=n_items; ++i)
  {
    const double angle
      = 2.0 * M_PI * (static_cast<double>(i+0) / static_cast<double>(n_items));
    const double angle_next
      = angle + 2.0 * M_PI * (0.5 / static_cast<double>(n_items));

    const QPointF from(std::sin(angle     ) *  50.0, -std::cos(angle     ) *  50.0);
    const QPointF mid( std::sin(angle_next) * 100.0, -std::cos(angle_next) * 100.0);
    const QPointF to(  std::sin(angle     ) * 150.0, -std::cos(angle     ) * 150.0);

    QtGroupItem * const item = new QtGroupItem(from,mid,to);
    scene()->addItem(item);
  }
}
