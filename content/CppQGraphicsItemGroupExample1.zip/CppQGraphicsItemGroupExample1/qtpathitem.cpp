#include <cassert>
#include <QPainter>
#include "qtpathitem.h"
#include "qtrectitem.h"

QtPathItem::QtPathItem(
  const QtRectItem * const from,
  const QtRectItem * const mid,
  const QtRectItem * const to,
  QGraphicsItem *parent, QGraphicsScene *scene)
  : QGraphicsPathItem(parent,scene),
    m_from(from),
    m_mid(mid),
    m_to(to)
{
  assert(!(flags() & QGraphicsItem::ItemIsMovable) );
  assert(!(flags() & QGraphicsItem::ItemIsSelectable) );
}

void QtPathItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
  QPainterPath path;
  path.moveTo(m_from->pos());
  path.quadTo(m_mid->pos(),m_to->pos());
  this->setPath(path);

  QGraphicsPathItem::paint(painter,option,widget);
}
