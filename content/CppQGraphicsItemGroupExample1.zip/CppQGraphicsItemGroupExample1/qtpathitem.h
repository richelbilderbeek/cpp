#ifndef QTPATHITEM_H
#define QTPATHITEM_H

#include <QGraphicsPathItem>

struct QtRectItem;

struct QtPathItem : public QGraphicsPathItem
{
  QtPathItem(
    const QtRectItem * const from,
    const QtRectItem * const mid,
    const QtRectItem * const to,
    QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  protected:
  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

  private:
  const QtRectItem * const m_from;
  const QtRectItem * const m_mid;
  const QtRectItem * const m_to;
};

#endif // QTPATHITEM_H
