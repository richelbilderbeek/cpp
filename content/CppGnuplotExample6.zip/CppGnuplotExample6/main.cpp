#include <cmath>
#include <fstream>
#include <string>
#include <cstdlib>
#include <QApplication>
#include <QLabel>

int main(int argc, char *argv[])
{
  QApplication a(argc,argv);

  const std::string dat_filename = "test.data";

  //Create data file
  {
    std::ofstream f(dat_filename.c_str());
    const int maxx = 100;
    for (int x = 0; x!=maxx; ++x)
    {
      const double f_x = static_cast<double>(x) / static_cast<double>(maxx);
      const double x_co = f_x * 2.0 * M_PI;
      const double y = std::cos(x_co);
      f << x_co << " " << y << '\n';
    }
  }

  #ifdef WIN32
  const std::string exe = "C:\\Progra~1\\gnuplot\\bin\\gnuplot.exe";
  #else
  const std::string exe = "gnuplot";
  #endif

  const std::string cmd_filename = "test.txt";
  const std::string pic_filename = "test.png";

  {
    std::ofstream f(cmd_filename.c_str());

    f <<
      "set terminal pngcairo\n"
      "set output '" << pic_filename <<"'\n"
      "set title \"Example 6\"\n"
      "set xlabel \"X coordinat\"\n"
      "set ylabel \"Y coordinat\"\n"
      "plot \"" << dat_filename<< "\" with lines\n";
  }

  const std::string cmd = exe + " " + cmd_filename;

  std::system(cmd.c_str());

  QLabel label;
  label.setPixmap(QPixmap(pic_filename.c_str()));
  label.show();

  return a.exec();
}
