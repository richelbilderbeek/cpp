#include <algorithm>
#include <vector>

///Sort a std::vector using insertion sort
///From http://www.richelbilderbeek.nl/CppInsertionSort.htm
template <typename T>
void InsertionSort(std::vector<T>& v)
{
  const int size = v.size();
  for(int i=1; i!=size; ++i)
  {
    for(int j=0; j<i; ++j)
    {
      if (v[j] > v[i])
      {
        const int temp = v[j];
        v[j] = v[i];
        for(int k=i; k>j; --k) { v[k] = v[k-1]; }
        v[j+1] = temp;
      }
    }
  }
}

const std::vector<int> CreateVector()
{
  std::vector<int> v;
  for (int i=0; i!=1000; ++i) v.push_back(std::rand() - std::rand());
  std::random_shuffle(v.begin(),v.end());
  return v;
}

#include <cassert>

int main()
{
  for (int i=0; i!=100; ++i)
  {
    const std::vector<int> v = CreateVector();

    std::vector<int> w = v;
    InsertionSort(w);

    std::vector<int> x = v;
    std::sort(x.begin(),x.end());

    assert(w == x);
  }

}
