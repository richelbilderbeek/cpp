#include <cmath>
#include <fstream>
#include <string>
#include <cstdlib>
#include <QApplication>
#include <QLabel>

int main(int argc, char *argv[])
{
  QApplication a(argc,argv);

  const std::string dat_filename = "test.data";

  //Create data file
  {
    std::ofstream f(dat_filename.c_str());
    for (double y = -10.0; y < 10.0; y+=0.1)
    {
      for (double x = -10.0; x < 10.0; x+=0.1)
      {
        const double z = std::cos(x) * std::sin(y);
        f << x << " " << y << " " << z << '\n';
      }
    }
  }

  #ifdef WIN32
  const std::string exe = "C:\\Progra~1\\gnuplot\\bin\\gnuplot.exe";
  #else
  const std::string exe = "gnuplot";
  #endif

  const std::string cmd_filename = "test.txt";
  const std::string pic_filename = "test.png";

  {
    std::ofstream f(cmd_filename.c_str());

    f <<
      "set terminal pngcairo\n"
      "set output '" << pic_filename <<"'\n"
      "set dgrid3d 20,20,1\n"
      "set dummy u,v\n"
      "set key inside right top vertical Right noreverse enhanced autotitles box linetype -1 linewidth 1.000\n"
      "set style data lines\n"
      "set title \"Example 3\"\n"
      "set xlabel \"X coordinat\"\n"
      "set ylabel \"Y coordinat\"\n"
      "set zlabel \"Z value\"\n"
      "splot \"" << dat_filename<< "\"\n";
  }

  const std::string cmd = exe + " " + cmd_filename;

  std::system(cmd.c_str());

  QLabel label;
  label.setPixmap(QPixmap(pic_filename.c_str()));
  label.show();

  return a.exec();
}
