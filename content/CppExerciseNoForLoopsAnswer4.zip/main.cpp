struct Widget
{
  void DoIt() const { /* do it */ }
};

#include <algorithm>
#include <vector>

void DoItCpp0x(const std::vector<Widget>& v)
{
  std::for_each(v.begin(),v.end(),[](const Widget& w) { w.DoIt(); } );
}


#include <algorithm>
#include <vector>
#include <boost/mem_fn.hpp>

void DoItBoost(const std::vector<Widget>& v)
{
  std::for_each(v.begin(),v.end(),boost::mem_fn(&Widget::DoIt));
}

#include <algorithm>
#include <functional>
#include <numeric>
#include <vector>

void DoItStl(const std::vector<Widget>& v)
{
  std::for_each(v.begin(),v.end(),std::mem_fun_ref(&Widget::DoIt));
}

#include <vector>

void DoItFor(const std::vector<Widget>& v)
{
  const int sz = static_cast<int>(v.size());
  for (int i=0; i!=sz; ++i)
  {
    v[i].DoIt();
  }
}

int main()
{

}
