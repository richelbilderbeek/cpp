#ifndef QTRECTITEM_H
#define QTRECTITEM_H

#include <QGraphicsRectItem>

struct QtRectItem : public QGraphicsRectItem
{
  QtRectItem(QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);
};

#endif // QTRECTITEM_H
