#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "qtrectitem.h"

#include <cassert>
#include <sstream>
#include <QGraphicsScene>
#include <QPainter>

QtRectItem::QtRectItem(QGraphicsItem *parent, QGraphicsScene *scene)
 : QGraphicsRectItem(parent,scene)
{
  this->setFlags(
      QGraphicsItem::ItemIsFocusable
    | QGraphicsItem::ItemIsMovable
    | QGraphicsItem::ItemIsSelectable);
  const double width  = 64.0; //pixels
  const double height = 32.0; //pixels
  this->setRect(-0.5 * width, -0.5 * height, width, height);
}
