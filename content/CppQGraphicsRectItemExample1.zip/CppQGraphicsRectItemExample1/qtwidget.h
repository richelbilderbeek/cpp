#ifndef QTWIDGET_H
#define QTWIDGET_H

#include <QGraphicsView>

///The widget holding the items
struct QtWidget : public QGraphicsView
{
  QtWidget(QWidget *parent = 0);
};

#endif // QTWIDGET_H
