#include <algorithm>
#include <functional>
#include <cassert>
#include <vector>

//Can even define both!
#define DEFINE_OPERATOR_EQUAL_AS_MEMBER_FUNCTION
#define DEFINE_OPERATOR_EQUAL_AS_FREE_FUNCTION

struct Test
{
  Test(const int x, const int y) : m_x(x), m_y(y) {}
  int GetX() const { return m_x; }
  int GetY() const { return m_y; }

  #ifdef DEFINE_OPERATOR_EQUAL_AS_MEMBER_FUNCTION
  bool operator==(const Test rhs)
  {
    return this->GetX() == rhs.GetX() && this->GetY() == rhs.GetY();
  }
  #endif

  private:
  int m_x;
  int m_y;
};


#ifdef DEFINE_OPERATOR_EQUAL_AS_FREE_FUNCTION
bool operator==(const Test& lhs, const Test rhs)
{
  return lhs.GetX() == rhs.GetX() && lhs.GetY() == rhs.GetY();
}
#endif

int main()
{
  std::vector<Test> v;
  v.push_back(Test(0,0));
  v.push_back(Test(1,1));
  v.push_back(Test(2,2));
  v.push_back(Test(0,0));
  assert(v[0] == v[3]); //Both ways work
  assert(std::count(v.begin(),v.end(),Test(0,0)) == 2); //Both ways work
}
