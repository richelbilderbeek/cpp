#include <QApplication>
#include "dialog.h"

const std::string CreateStyleSheet()
{
  const std::string s =
    "QPushButton:enabled {"
    "  background-color: green;"
    "}"
    "QPushButton:disabled {"
    "  background-color: red;"
    "}";
  return s;
}

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  a.setStyleSheet(CreateStyleSheet().c_str());
  Dialog w;
  w.show();

  return a.exec();
}
