#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_button_toggle_clicked()
{
  ui->button_show->setEnabled( ! ui->button_show->isEnabled() );

  ui->button_show->setText(
    ui->button_show->isEnabled()
    ? QString("I am enabled")
    : QString("I am disabled"));
}
