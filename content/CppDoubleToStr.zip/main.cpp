#include <string>

//From http://www.richelbilderbeek.nl/CppDoubleToStr.htm
const std::string DoubleToStrCpp0x(const double x)
{
  return std::to_string(x);
}

#include <sstream>
#include <stdexcept>
#include <string>

//From http://www.richelbilderbeek.nl/CppDoubleToStr.htm
const std::string DoubleToStrCpp98(const double x)
{
  std::ostringstream s;
  if (!(s << x)) throw std::logic_error("DoubleToStr failed");
  return s.str();
}

#include <string>
#include <boost/lexical_cast.hpp>

//From http://www.richelbilderbeek.nl/CppDoubleToStr.htm
const std::string DoubleToStrBoost(const double x)
{
  return boost::lexical_cast<std::string>(x);
}

#include <cassert>

int main()
{
  assert(DoubleToStrCpp0x(123.456) == "123.456000");
  assert(DoubleToStrBoost(123.456) == "123.456");
  assert(DoubleToStrCpp98(123.456) == "123.456");
}
