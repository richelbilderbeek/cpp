///CppQtCrosscompilerToWindowsExample3:
///cross-compiling a console application with
///a library (that is: boost_filesystem).
//---------------------------------------------------------------------------
#include <iostream>
#include <string>
#include <vector>
//---------------------------------------------------------------------------
#include <boost/filesystem.hpp>
//---------------------------------------------------------------------------
//From http://www.richelbilderbeek.nl/CppGetFilesInFolder.htm
const std::vector<std::string> GetFilesInFolder(const std::string& folder)
{
  std::vector<std::string> v;

  const boost::filesystem::path my_folder
    = boost::filesystem::system_complete(
        boost::filesystem::path(folder));

  if (!boost::filesystem::is_directory(my_folder)) return v;

  const boost::filesystem::directory_iterator j;
  for ( boost::filesystem::directory_iterator i(my_folder);
        i != j;
        ++i)
  {
    if ( boost::filesystem::is_regular_file( i->status() ) )
    {
      const std::string filename = i->path().filename();
      //const std::string full_filename = folder + "/" + filename;
      v.push_back(filename);
    }
  }
  return v;
}
//---------------------------------------------------------------------------
//From http://www.richelbilderbeek.nl/CppGetPath.htm
const std::string GetPath(const std::string& filename)
{
  return boost::filesystem::path(filename).parent_path().string();
}
//---------------------------------------------------------------------------
int main(int, char* argv[])
{
  const std::vector<std::string> v = GetFilesInFolder(GetPath(argv[0]));
  std::copy(v.begin(),v.end(),std::ostream_iterator<std::string>(std::cout,"\n"));
  std::cout << "Number of files: " << v.size() << '\n';
}
//---------------------------------------------------------------------------




