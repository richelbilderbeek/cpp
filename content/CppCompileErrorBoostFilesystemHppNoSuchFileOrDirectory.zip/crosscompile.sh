#Works fine
#i586-mingw32msvc-g++ -o MyWin.exe main.cpp -I/usr/include -I/usr/include/boost -L/usr/local/lib -lboost_filesystem
#Try to fix compile error by no support for no-argument throw
#Works just as well, but is more precise
#i586-mingw32msvc-g++ -V 4.4.2 -x c++ -o MyWin.exe main.cpp -I/usr/include -I/usr/include/boost -L/usr/local/lib -lboost_filesystem    
#Switch to different include paths -> fixes error!
i586-mingw32msvc-g++ -o MyWin.exe main.cpp -I/usr/i586-mingw32msvc/include -I/usr/include/boost -L/usr/local/lib -lboost_filesystem




