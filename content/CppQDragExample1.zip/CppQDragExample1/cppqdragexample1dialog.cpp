#include "cppqdragexample1dialog.h"
#include "ui_cppqdragexample1dialog.h"

CppQDragExample1Dialog::CppQDragExample1Dialog(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::CppQDragExample1Dialog)
{
  ui->setupUi(this);

  ui->listWidget_1->setAcceptDrops(true);
  ui->listWidget_2->setAcceptDrops(true);
  ui->listWidget_1->setDragEnabled(true);
  ui->listWidget_2->setDragEnabled(true);

  ui->listWidget_1->setDragDropMode(QAbstractItemView::DragDrop);
  ui->listWidget_2->setDragDropMode(QAbstractItemView::DragDrop);

  ui->listWidget_1->setDefaultDropAction(Qt::MoveAction);
  ui->listWidget_2->setDefaultDropAction(Qt::MoveAction);
}

CppQDragExample1Dialog::~CppQDragExample1Dialog()
{
  delete ui;
}
