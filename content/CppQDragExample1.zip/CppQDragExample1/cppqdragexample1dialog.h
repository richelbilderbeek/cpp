#ifndef CPPQDRAGEXAMPLE1DIALOG_H
#define CPPQDRAGEXAMPLE1DIALOG_H

#include <QDialog>

namespace Ui {
  class CppQDragExample1Dialog;
}

class CppQDragExample1Dialog : public QDialog
{
  Q_OBJECT
  
public:
  explicit CppQDragExample1Dialog(QWidget *parent = 0);
  ~CppQDragExample1Dialog();
  
private:
  Ui::CppQDragExample1Dialog *ui;
};

#endif // CPPQDRAGEXAMPLE1DIALOG_H
