#include <boost/static_assert.hpp>
#include <iostream>

struct Struct
{
  double d;
  int i;
};

union Union
{
  double d;
  int i;
};

int main()
{
  //Check that a unions' size is
  //smaller than a struct's
  BOOST_STATIC_ASSERT(sizeof(Union)<sizeof(Struct));

  //Create a clean union
  Union u;
  u.i = 0;
  u.d = 0;

  u.i = 1000;
  std::cout
    << "int   : " << u.i << '\n'
    << "double: " << u.d << '\n';
  u.d = 1000.0;
  std::cout
    << "int   : " << u.i << '\n'
    << "double: " << u.d << '\n';

}
