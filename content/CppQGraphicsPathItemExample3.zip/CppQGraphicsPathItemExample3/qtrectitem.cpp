#include "qtrectitem.h"

QtRectItem::QtRectItem(QGraphicsItem *parent, QGraphicsScene *scene)
 : QGraphicsRectItem(parent,scene)
{
  this->setFlags(
      QGraphicsItem::ItemIsSelectable
    | QGraphicsItem::ItemIsMovable);

  const double length = 8;
  this->setRect(-length/2.0,-length/2.0,length,length);
}
