#include <cassert>
#include <QPainter>
#include "qtpathitem.h"
#include "qtrectitem.h"

QtPathItem::QtPathItem(
  const QtRectItem * const from,
  const QtRectItem * const mid,
  const QtRectItem * const to,
  QGraphicsItem *parent, QGraphicsScene *scene)
  : QGraphicsPathItem(parent,scene),
    m_from(from),
    m_mid(mid),
    m_to(to)
{
  assert(!(flags() & QGraphicsItem::ItemIsMovable) );
  assert(!(flags() & QGraphicsItem::ItemIsSelectable) );
}

void QtPathItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
  QPainterPath path;
  path.moveTo(m_from->pos());
  //Line must go _though_ mid pos, instead of using it as a virtual hinge point
  //Solution:
  // - define point p as the middle between from and to
  // - define point q as the mirror point of q, using mid_pos as a mirror
  const QPointF p((m_from->pos() + m_to->pos()) / 2.0);
  const double dx = m_mid->pos().x() - p.x();
  const double dy = m_mid->pos().y() - p.y();
  const QPointF q(p.x() + dx + dx, p.y() + dy + dy);
  path.quadTo(q,m_to->pos());
  this->setPath(path);

  QGraphicsPathItem::paint(painter,option,widget);
}
