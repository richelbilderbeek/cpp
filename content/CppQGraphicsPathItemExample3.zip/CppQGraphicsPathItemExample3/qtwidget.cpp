#include <cassert>
#include <QGraphicsScene>
#include "qtrectitem.h"
#include "qtpathitem.h"
#include "qtwidget.h"

QtWidget::QtWidget(QWidget *parent)
  : QGraphicsView(new QGraphicsScene,parent)
{
  const int n_items = 18;
  std::vector<QtRectItem *> rects;

  for (int i=0; i!=n_items; ++i)
  {
    const double angle = 2.0 * M_PI * (static_cast<double>(i) / static_cast<double>(n_items));
    const double x1 =  std::sin(angle) * 100.0;
    const double y1 = -std::cos(angle) * 100.0;
    QtRectItem * const rect = new QtRectItem;
    rect->setPos(x1,y1);
    scene()->addItem(rect);
    rects.push_back(rect);
  }
  for (int i=0; i<n_items-2; i+=3)
  {
    assert(i + 2 < n_items);
    QtPathItem * const item = new QtPathItem(
      rects[(i+0) % n_items],
      rects[(i+1) % n_items],
      rects[(i+2) % n_items]);
    scene()->addItem(item);
  }
}
