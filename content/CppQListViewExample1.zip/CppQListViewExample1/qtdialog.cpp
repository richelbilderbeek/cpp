#include "qtdialog.h"

#include <QStandardItemModel>
#include <QStyledItemDelegate>
#include "ui_qtdialog.h"

QtDialog::QtDialog(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::QtDialog),
  m_model(new QStandardItemModel)
{
  ui->setupUi(this);
  ui->list_view->setModel(m_model);
  ui->list_view->setItemDelegate(new QStyledItemDelegate);
}

QtDialog::~QtDialog()
{
  delete ui;
}

void QtDialog::on_button_clicked()
{
  QStandardItem * const item = new QStandardItem;
  item->setText("");
  m_model->appendRow(item);
  ui->list_view->scrollToBottom();
  ui->list_view->setCurrentIndex(item->index());
  ui->list_view->edit(item->index());

}
