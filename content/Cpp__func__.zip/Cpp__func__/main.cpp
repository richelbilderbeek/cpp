#include <iostream>

void ShowFunc()
{
  std::cout << __func__ << '\n';
}

int main()
{
  ShowFunc();

  std::cout << __func__ << '\n';
}

/* Screen output:

ShowFunc
main

*/
