#ifndef DIALOGPOPUP_H
#define DIALOGPOPUP_H

#include <QDialog>

namespace Ui {
    class DialogPopUp;
}

class DialogPopUp : public QDialog
{
    Q_OBJECT

public:
    explicit DialogPopUp(QWidget *parent = 0);
    ~DialogPopUp();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::DialogPopUp *ui;
};

#endif // DIALOGPOPUP_H
