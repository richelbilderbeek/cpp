#ifndef DIALOGMAIN_H
#define DIALOGMAIN_H

#include <QDialog>

namespace Ui {
    class DialogMain;
}

class DialogMain : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMain(QWidget *parent = 0);
    ~DialogMain();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::DialogMain *ui;
private slots:
    void onClickShow();
};

#endif // DIALOGMAIN_H
