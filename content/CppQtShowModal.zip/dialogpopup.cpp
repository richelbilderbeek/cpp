#include "dialogpopup.h"
#include "ui_dialogpopup.h"

DialogPopUp::DialogPopUp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogPopUp)
{
    ui->setupUi(this);
}

DialogPopUp::~DialogPopUp()
{
    delete ui;
}

void DialogPopUp::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
