#include <boost/shared_ptr.hpp>
#include "dialogpopup.h"
#include "dialogmain.h"
#include "ui_dialogmain.h"

DialogMain::DialogMain(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMain)
{
  ui->setupUi(this);
  QObject::connect(ui->button_show,SIGNAL(clicked()),this,SLOT(onClickShow()));
}

DialogMain::~DialogMain()
{
  delete ui;
}

void DialogMain::changeEvent(QEvent *e)
{
  QDialog::changeEvent(e);
  switch (e->type()) {
  case QEvent::LanguageChange:
    ui->retranslateUi(this);
    break;
  default:
    break;
  }
}

void DialogMain::onClickShow()
{
  boost::shared_ptr<DialogPopUp> f(new DialogPopUp);
  this->hide(); //Hide the main window
  f->exec();    //Show the pop-up modally
  this->show(); //Show the main window again
}
