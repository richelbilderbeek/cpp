#ifndef QTRECTITEM_H
#define QTRECTITEM_H

#include <QGraphicsRectItem>

struct QtRectItem : public QGraphicsRectItem
{
  QtRectItem(QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // QTRECTITEM_H
