int main()
{
  char16_t c;
  char32_t d;
}
