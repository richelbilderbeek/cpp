#include <QtGui/QApplication>
#include <QtGui/QDialog>

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  QDialog d;
  d.setWindowTitle("Hello Qt");
  d.show();
  return a.exec();
}
