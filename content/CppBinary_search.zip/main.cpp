#include <algorithm>
#include <cassert>
#include <iostream>
#include <vector>

struct Gossip
{
  Gossip(const int any_i) : i(any_i) {}
  private:
  int i;
  friend bool operator<(const Gossip& lhs, const Gossip& rhs);
};

bool operator<(const Gossip& lhs, const Gossip& rhs)
{
  std::cout << "bool operator<(const Gossip& lhs, const Gossip& rhs)\n";
  return lhs.i < rhs.i;
}

int main()
{
  std::vector<Gossip> v;
  for (int i=0; i!=100; ++i)
  {
    v.push_back(Gossip(i));
  }

  std::cout << "I will be found\n";
  assert(std::binary_search(v.begin(),v.end(),Gossip(90))==true);
  std::cout << "I will not be found\n";
  assert(std::binary_search(v.begin(),v.end(),Gossip(100))==false);
}
