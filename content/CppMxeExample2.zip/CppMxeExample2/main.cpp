#include <iostream>

int main()
{
  const auto s = "Hello C++0x";
  std::cout << s << '\n';
}
