#include <QMouseEvent>
#include <QPainter>

#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog),
    m_show_1st(true)
{
  ui->setupUi(this);
}

Dialog::~Dialog()
{
  delete ui;
}

void Dialog::changeEvent(QEvent *e)
{
  QDialog::changeEvent(e);
  switch (e->type()) {
  case QEvent::LanguageChange:
    ui->retranslateUi(this);
    break;
  default:
    break;
  }
}

void Dialog::paintEvent(QPaintEvent*)
{
  QPainter painter(this);
  QPixmap pixmap(m_show_1st
    ? ":/images/PlayerWon1.png"
    : ":/images/PlayerScared.png");
  painter.drawPixmap(ui->widget->geometry(),pixmap);
}

void Dialog::mousePressEvent(QMouseEvent * event)
{
  //From the QMouseEvent Help:
  //'Mouse move events will occur only when a mouse button
  // is pressed down, unless mouse tracking has been
  // enabled with QWidget::setMouseTracking()'.
  //So no need to check for event type
  if (ui->widget->geometry().contains(
    event->x(), event->y()))
  {
    m_show_1st = !m_show_1st;
    repaint();
  }
}
